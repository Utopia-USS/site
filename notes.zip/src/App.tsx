import React from 'react';
import logo from './logo.svg';
import './App.css';
import NavBar from './components/nav-bar/NavBar';

function App() {
  return (
    <NavBar/>
  );
}

export default App;
