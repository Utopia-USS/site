import React from "react";
import NavBarScrollingState from "./models/NavBarScrollingState";
import CSS from 'csstype';
import {NavBarConfig} from "./NavBarConfig";

type Props = {
  navBarScrollingState: NavBarScrollingState;
};

const distancingBoxStyle: CSS.Properties = {
  width: '100%',
  height: `${NavBarConfig.maxAppBarHeight}px`,
  display: 'block',
  color: 'red',
}

export const NavBarView: React.FC<Props> = props => {
  const { navBarScrollingState } = props;

  return (
    <nav id="app-bar">
      <div id="distancing-box" style={distancingBoxStyle}>
      </div>
    </nav>
  );
};