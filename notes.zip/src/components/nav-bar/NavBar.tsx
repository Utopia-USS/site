import React, {Component} from 'react';
import NavBarScrollingState from './models/NavBarScrollingState';
import {NavBarConfig} from './NavBarConfig';
import { NavBarView } from './NavBarView';

type State = {
  navBarScrollingState: NavBarScrollingState;
  lastOffset: number;
};

type Props = {};

class NavBar extends Component<Props, State> {

  readonly state: State = {
    navBarScrollingState: {
      appBarOffset: 0,
      appBarHeight: NavBarConfig.maxAppBarHeight
    },
    lastOffset: 0,
  };

  render() {
    return(<NavBarView navBarScrollingState={this.state.navBarScrollingState}/>);
  }

}

export default NavBar