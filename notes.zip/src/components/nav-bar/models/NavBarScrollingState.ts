type NavBarScrollingState = {
  appBarOffset: number;
  appBarHeight: number;
}

export default NavBarScrollingState;