type CustomAppBarButton = {
  text: string;
  onPressed: () => void;
}

export namespace NavBarConfig {
  export const menuButtons : ReadonlyArray<CustomAppBarButton> = [
    {
        text: "Portfolio",
        onPressed: () => null,
    },
    {
      text: "Team",
      onPressed: () => null,
    }
  ];

  export const scrollDelay = 150;

  // horizontal
  export const paddingWidth = 100.0;
  export const buttonWidth = 100.0;
  export const minLogoWidth = 100.0;

  // vertical
  export const maxAppBarHeight = 400.0;
  export const paddingHeightRatio = 8;
  export const buttonHeight = 50.0;
  export const minLogoHeight = 40.0;

  export const minWidth = () =>
      paddingWidth + minLogoWidth + menuButtons.length * buttonWidth;

      export const minHeight = () =>
      Math.max(minLogoHeight, buttonHeight) * (1 + 2/paddingHeightRatio);
}